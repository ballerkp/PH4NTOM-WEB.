# PH4NTØM Web + Owner Dashboard

## What is included
- Public PH4NTØM landing page
- Cybersecurity-focused About / Capabilities / Partners / Report Center
- Private Owner Dashboard
- Discord OAuth2 login
- Owner-only authorization using `OWNER_DISCORD_ID`
- Partner CRUD management
- Activity/audit log
- SQLite database
- Responsive mobile layout

## Important security note
Do NOT put Discord client secrets, bot tokens, or session secrets in frontend JavaScript. They belong in `.env` on the server. Discord documents bot tokens and OAuth credentials as sensitive and recommends keeping secrets out of source code.

## Setup
1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Create a Discord application and configure its OAuth2 redirect URI.
4. Put your Discord application credentials and your own Discord user ID in `.env`.
5. Run:
   npm install
   npm start
6. Open:
   http://localhost:3000

For production, use HTTPS and a real persistent session store instead of the default Express MemoryStore.


## Owner Dashboard — Site Control

The dashboard now includes:
- Live server status
- Process ID, uptime and Node version
- Restart Website
- Shutdown Website

### Recommended production setup with PM2

Install PM2:
```bash
npm install -g pm2
pm2 start server.js --name ph4ntom-web
pm2 save
pm2 startup
```

With PM2, the dashboard's restart action exits the Node process and PM2 automatically starts it again. The shutdown action stops the process; start it again with:
```bash
pm2 start ph4ntom-web
```

Never expose these controls without the owner authorization check and HTTPS.


## Owner configured

The dashboard is configured for this Discord owner ID:

`1543828096522653837`

The owner username is not used for authorization; the Discord ID is the access key.

Before deploying, fill in:
- `DISCORD_CLIENT_ID`
- `DISCORD_CLIENT_SECRET`
- `DISCORD_REDIRECT_URI`
- `SESSION_SECRET`

Do not publish the `.env` file.
