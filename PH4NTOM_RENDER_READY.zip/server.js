import express from "express";
import session from "express-session";
import Database from "better-sqlite3";
import dotenv from "dotenv";
import crypto from "crypto";
import path from "path";
import { exec } from "child_process";
import { fileURLToPath } from "url";

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const db = new Database("ph4ntom.db");

db.exec(`
CREATE TABLE IF NOT EXISTS partners (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  type TEXT DEFAULT 'Security',
  website TEXT,
  invite TEXT,
  status TEXT DEFAULT 'Pending',
  notes TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS activity (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  action TEXT NOT NULL,
  detail TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.set("trust proxy", 1);
app.use(session({
  secret: process.env.SESSION_SECRET || crypto.randomBytes(32).toString("hex"),
  resave:false,
  saveUninitialized:false,
  cookie:{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:86400000}
}));
app.use(express.static(path.join(__dirname,"public")));

function ownerOnly(req,res,next){
  if(!req.session.user) return res.status(401).json({error:"Not authenticated"});
  if(req.session.user.id !== process.env.OWNER_DISCORD_ID)
    return res.status(403).json({error:"Owner access required"});
  next();
}

app.get("/api/config",(req,res)=>res.json({invite:process.env.PH4NTOM_INVITE || "#"}));
app.get("/api/me",(req,res)=>res.json({user:req.session.user||null, owner:req.session.user?.id===process.env.OWNER_DISCORD_ID}));

app.get("/auth/discord",(req,res)=>{
  const params=new URLSearchParams({
    client_id:process.env.DISCORD_CLIENT_ID,
    response_type:"code",
    redirect_uri:process.env.DISCORD_REDIRECT_URI,
    scope:"identify"
  });
  res.redirect("https://discord.com/oauth2/authorize?"+params.toString());
});

app.get("/auth/discord/callback",async(req,res)=>{
  try{
    const tokenBody=new URLSearchParams({
      client_id:process.env.DISCORD_CLIENT_ID,
      client_secret:process.env.DISCORD_CLIENT_SECRET,
      grant_type:"authorization_code",
      code:req.query.code,
      redirect_uri:process.env.DISCORD_REDIRECT_URI
    });
    const tokenRes=await fetch("https://discord.com/api/oauth2/token",{
      method:"POST",
      headers:{"Content-Type":"application/x-www-form-urlencoded"},
      body:tokenBody
    });
    if(!tokenRes.ok) throw new Error("Token exchange failed");
    const token=await tokenRes.json();

    const userRes=await fetch("https://discord.com/api/users/@me",{
      headers:{Authorization:`Bearer ${token.access_token}`}
    });
    if(!userRes.ok) throw new Error("Discord user lookup failed");
    const user=await userRes.json();

    req.session.user={id:user.id,username:user.global_name||user.username,avatar:user.avatar};
    db.prepare("INSERT INTO activity(action,detail) VALUES(?,?)").run("LOGIN",`Discord user ${user.id}`);
    res.redirect("/dashboard.html");
  }catch(e){
    console.error(e);
    res.redirect("/?error=auth");
  }
});

app.post("/auth/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));

app.get("/api/partners",ownerOnly,(req,res)=>{
  res.json(db.prepare("SELECT * FROM partners ORDER BY id DESC").all());
});

app.post("/api/partners",ownerOnly,(req,res)=>{
  const {name,type,website,invite,status,notes}=req.body;
  if(!name?.trim()) return res.status(400).json({error:"Partner name required"});
  const info=db.prepare(`INSERT INTO partners(name,type,website,invite,status,notes) VALUES(?,?,?,?,?,?)`)
    .run(name.trim(),type||"Security",website||"",invite||"",status||"Pending",notes||"");
  db.prepare("INSERT INTO activity(action,detail) VALUES(?,?)").run("PARTNER_CREATED",name.trim());
  res.json(db.prepare("SELECT * FROM partners WHERE id=?").get(info.lastInsertRowid));
});

app.patch("/api/partners/:id",ownerOnly,(req,res)=>{
  const p=db.prepare("SELECT * FROM partners WHERE id=?").get(req.params.id);
  if(!p) return res.status(404).json({error:"Not found"});
  const fields=["name","type","website","invite","status","notes"];
  const updates=fields.filter(k=>req.body[k]!==undefined);
  if(!updates.length) return res.json(p);
  const sql=`UPDATE partners SET ${updates.map(k=>`${k}=?`).join(",")} WHERE id=?`;
  db.prepare(sql).run(...updates.map(k=>req.body[k]),req.params.id);
  db.prepare("INSERT INTO activity(action,detail) VALUES(?,?)").run("PARTNER_UPDATED",p.name);
  res.json(db.prepare("SELECT * FROM partners WHERE id=?").get(req.params.id));
});

app.delete("/api/partners/:id",ownerOnly,(req,res)=>{
  const p=db.prepare("SELECT * FROM partners WHERE id=?").get(req.params.id);
  if(!p) return res.status(404).json({error:"Not found"});
  db.prepare("DELETE FROM partners WHERE id=?").run(req.params.id);
  db.prepare("INSERT INTO activity(action,detail) VALUES(?,?)").run("PARTNER_DELETED",p.name);
  res.json({ok:true});
});


function runProcessCommand(command){
  return new Promise((resolve,reject)=>{
    exec(command,{timeout:15000},(error,stdout,stderr)=>{
      if(error) return reject(new Error(stderr || error.message));
      resolve(stdout.trim());
    });
  });
}

app.get("/api/site-status",ownerOnly,async(req,res)=>{
  res.json({
    status:"online",
    pid:process.pid,
    uptime:Math.round(process.uptime()),
    node:process.version
  });
});

app.post("/api/site/restart",ownerOnly,async(req,res)=>{
  db.prepare("INSERT INTO activity(action,detail) VALUES(?,?)")
    .run("SITE_RESTART","Owner requested a restart");
  res.json({ok:true,message:"Restart requested"});
  setTimeout(()=>{
    // PM2/systemd/Docker should restart the process after exit.
    process.exit(0);
  },500);
});

app.post("/api/site/shutdown",ownerOnly,async(req,res)=>{
  db.prepare("INSERT INTO activity(action,detail) VALUES(?,?)")
    .run("SITE_SHUTDOWN","Owner requested shutdown");
  res.json({ok:true,message:"Shutdown requested"});
  setTimeout(()=>process.exit(0),500);
});

app.get("/api/activity",ownerOnly,(req,res)=>{
  res.json(db.prepare("SELECT * FROM activity ORDER BY id DESC LIMIT 50").all());
});

app.get("*",(req,res)=>{
  res.sendFile(path.join(__dirname,"public","index.html"));
});

const port=Number(process.env.PORT||3000);
app.listen(port,()=>console.log(`PH4NTØM web running on http://localhost:${port}`));
