# PH4NTØM — Render Deployment

This package is prepared for Render.

## 1. Upload to GitHub
Create a GitHub repository and upload every file in this folder.

Do NOT upload:
- `.env`
- Discord client secrets
- bot tokens

## 2. Deploy on Render
Open Render and create a new **Web Service** from your GitHub repository.

The included `render.yaml` contains:
- Node runtime
- `npm install` build
- `npm start` start command
- health check
- Owner ID `1543828096522653837`
- PH4NTØM invite
- generated session secret
- placeholders for Discord OAuth credentials

## 3. Discord OAuth2
In your Discord Developer Portal, create/configure an OAuth2 application.

Set the redirect URI to:

https://YOUR-RENDER-DOMAIN.onrender.com/auth/discord/callback

Then set these Render environment variables:
- `DISCORD_CLIENT_ID`
- `DISCORD_CLIENT_SECRET`
- `DISCORD_REDIRECT_URI`

`DISCORD_REDIRECT_URI` must exactly match the URL registered in Discord.

## 4. Owner access
The dashboard authorizes the Discord user ID:

1543828096522653837

The username is not used for authorization.

## 5. Important: persistent database
The included SQLite database is suitable for testing/small deployments, but Render web services have ephemeral filesystems unless you configure persistent storage. For production partner data, move the database to a managed PostgreSQL database or attach appropriate persistent storage.

## 6. Restart / Shutdown
The Owner Dashboard has Restart and Shutdown controls.

On Render, the platform manages the web service process. The controls in this package terminate the Node process; Render may automatically restart it depending on the service state and platform behavior. They should not be treated as a substitute for Render's own service controls.

## 7. Recommended security
- Use HTTPS (Render provides it for the service).
- Keep OAuth secrets only in Render Environment Variables.
- Keep the Owner ID authorization on the server.
- Do not expose administrative endpoints without authentication.
